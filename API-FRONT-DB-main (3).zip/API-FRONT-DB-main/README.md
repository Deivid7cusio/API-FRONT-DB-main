Para ligar o projeto NPM START
Import de banco de dados
